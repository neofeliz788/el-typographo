﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace el_Typographo
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        public static string First_Rule_Of_Fight_CLub(string input)
        {

            string str = Regex.Replace(input, @"\s+([.,:;!?""”[)}\]>»])", "$1");

            str = Regex.Replace(str, @"(\w)([.,:;!?])(\w)", "$1$2 $3");


            str = Regex.Replace(str, @"\s*-\s*", " - ");


            str = Regex.Replace(str, @"([""“([{<«])\s*(\w)", " $1$2");
            str = Regex.Replace(str, @"(\w)([""”[)}\]>»])(\w)", "$1$2 $3");

            return str;
        }

        public static string Second_Rule_Of_Fight_CLub(string input)
        {
            return Regex.Replace(input, @"\s{2,}", " ");
        }

        public static string Ninth_Rule_Of_Fight_Club(string input)
        {
            return input.Replace("+-", "±").Replace("-+", "±");
        }
        public static string Twelfth_Rule_Of_Fight_Club(string input)
        {
            input = Regex.Replace(input, @"\^2", "²");
            input = Regex.Replace(input, @"\^3", "³");

            return input;
        }
        public static string Thirteenth_Rule_Of_Fight_Club(string input)
        {
            return input.Replace("...", "…");
        }
        public static string Secret_Rule_Of_Fight_CLub(string input)
        {
            return input.Replace("(", "{").Replace(")", "}");
        }
        public static string Absolutely_Absurd_Rule_Of_Fight_Club(string input)
        {
            return input.Replace("1488", "ПАСХАЛОЧКО ВРУБАЕМ ВЕНТИЛЯТОРЫ")
                .Replace("1161", "ПОСХАЛКОООО")
                .Replace("неожиданно", "НЕОЖИД")
                .Replace("свой", "SVO ZOV ЛИКВИДИРОВАН")
                .Replace("го", "ГОЙДА СВОИТЕЛЬНО НО КТО МАТЬ ЕГО НАПИСАЛ ЭТОТ ТЕКСТ?? - ДМИТРИЙ МАТЬ ЕГО УТКИН");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            if (textBox1.Text == "")
            {
                MessageBox.Show("Введи текст по братски");
            }
            textBox1.Text = First_Rule_Of_Fight_CLub(Second_Rule_Of_Fight_CLub(Ninth_Rule_Of_Fight_Club(Twelfth_Rule_Of_Fight_Club(Thirteenth_Rule_Of_Fight_Club(Secret_Rule_Of_Fight_CLub(Absolutely_Absurd_Rule_Of_Fight_Club(input)))))));
         

        }
    }
}
