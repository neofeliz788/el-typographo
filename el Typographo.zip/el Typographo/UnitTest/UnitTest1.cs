﻿using el_Typographo;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_Spacings()
        {
            string str = Form1.First_Rule_Of_Fight_CLub("пам парам пам парам , приветствую смотрящих .");
            Assert.AreEqual(str, "пам парам пам парам, приветствую смотрящих.");
        }
        [TestMethod]
        public void Test_Hyphen()
        {
            string str = Form1.First_Rule_Of_Fight_CLub("Я-человек");
            Assert.AreEqual(str, "Я - человек");
        }
        [TestMethod]
        public void Test_Brackets()
        {
            string str = Form1.First_Rule_Of_Fight_CLub("“ doinb ryze hack ”");
            Assert.AreEqual(str, " “doinb ryze hack”");
        }
        [TestMethod]
        public void Test_Space_Limitation()
        {
            string str = Form1.Second_Rule_Of_Fight_CLub("Всем дарова  друзья");
            Assert.AreEqual(str, "Всем дарова друзья");
        }
        [TestMethod]
        public void Test_Plus_Minus()
        {
            string str = Form1.Ninth_Rule_Of_Fight_Club("Ну я +- выпил 5 литров тротила");
            Assert.AreEqual(str, "Ну я ± выпил 5 литров тротила");
        }
        [TestMethod]
        public void Test_Degree()
        {
            string str = Form1.Twelfth_Rule_Of_Fight_Club("сколько будет 2^3?");
            Assert.AreEqual(str, "сколько будет 2³?");
        }
        [TestMethod]
        public void Test_Dots()
        {
            string str = Form1.Thirteenth_Rule_Of_Fight_Club("это просто жесть...");
            Assert.AreEqual(str, "это просто жесть…");
        }
        [TestMethod]
        public void Test_Changing_Brackets()
        {
            string str = Form1.Secret_Rule_Of_Fight_CLub("(((всем привет)))");
            Assert.AreEqual(str, "{{{всем привет}}}");
        }
        [TestMethod]
        public void Test_Pashalko()
        {
            string str = Form1.Absolutely_Absurd_Rule_Of_Fight_Club("сегодня мне исполнилось 1488 лет, а моему брату 1161");
            Assert.AreEqual(str, "сеГОЙДА СВОИТЕЛЬНО НО КТО МАТЬ ЕГО НАПИСАЛ ЭТОТ ТЕКСТ?? - ДМИТРИЙ МАТЬ ЕГО УТКИНдня мне исполнилось ПАСХАЛОЧКО ВРУБАЕМ ВЕНТИЛЯТОРЫ лет, а моему брату ПОСХАЛКОООО");
        }
        [TestMethod]
        public void Test_Pashalko_Again()
        {
            string str = Form1.Absolutely_Absurd_Rule_Of_Fight_Club("свой первый велосипед я купил тогда, когда неожиданно нашел на земле купюру в 5000 рублей");
            Assert.AreEqual(str, "SVO ZOV ЛИКВИДИРОВАН первый велосипед я купил тогда, когда НЕОЖИД нашел на земле купюру в 5000 рублей");
        }
    }
}
